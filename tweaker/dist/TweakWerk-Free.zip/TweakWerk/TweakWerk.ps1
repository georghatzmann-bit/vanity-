﻿# TweakWerk - ehrlicher Gaming-Optimizer fuer Windows 10/11
# Jede Aenderung wird vorher gesichert und kann mit einem Klick rueckgaengig gemacht werden.
# Keine Placebo-Tweaks, kein Abschalten von Virenschutz oder Windows-Updates.
#
# Diese Datei wird von build.py aus den Teilen in src/ zusammengesetzt. Aendere die Teile, nicht das Ergebnis.

$script:AppName    = 'TweakWerk'
$script:AppVersion = '0.1.0-beta'
$script:Edition    = 'Free'
$script:ProUrl     = ''
$script:DataDir    = Join-Path $env:LOCALAPPDATA $script:AppName
$script:BackupFile = Join-Path $script:DataDir 'backup.json'
$script:LogFile    = Join-Path $script:DataDir 'log.txt'

# ------------------------------------------------------------------ Kern: Log, Registry, Sicherung, Tweak-Engine

$script:Window = $null
$script:LogSink = $null   # von der Oberflaeche gesetzt: { param($Line, $Level) ... }

function Write-TWLog {
    param(
        [string]$Message,
        [ValidateSet('Info', 'Ok', 'Warn', 'Error')][string]$Level = 'Info'
    )
    $line = '{0}  {1}' -f (Get-Date -Format 'HH:mm:ss'), $Message
    if ($script:LogFile) {
        try { Add-Content -LiteralPath $script:LogFile -Value "[$Level] $line" -Encoding UTF8 -ErrorAction Stop } catch { }
    }
    if ($script:LogSink) { & $script:LogSink $line $Level } else { Write-Host $line }
}

function Update-TWUi {
    # Laesst die Oberflaeche kurz neu zeichnen, damit sie bei laengeren Aktionen nicht einfriert
    if ($script:Window) {
        $script:Window.Dispatcher.Invoke([action] {}, [System.Windows.Threading.DispatcherPriority]::Background)
    }
}

# --- Registry -------------------------------------------------------------------------------
# Eigene Wrapper statt Get-ItemProperty: keine Platzhalter-Probleme bei Namen wie "C:\Spiele\[x].exe"
# und immer die 64-Bit-Ansicht der Registry.

function Open-TWRegKey {
    param([string]$Path, [switch]$Writable, [switch]$Create)
    $hiveName, $subKey = $Path -split ':\\', 2
    $hive = switch ($hiveName) {
        'HKCU' { [Microsoft.Win32.RegistryHive]::CurrentUser }
        'HKLM' { [Microsoft.Win32.RegistryHive]::LocalMachine }
        default { throw "Unbekannter Registry-Pfad: $Path" }
    }
    $base = [Microsoft.Win32.RegistryKey]::OpenBaseKey($hive, [Microsoft.Win32.RegistryView]::Registry64)
    if ($Create) { return $base.CreateSubKey($subKey) }
    return $base.OpenSubKey($subKey, [bool]$Writable)
}

function Get-TWRegValue {
    # Liefert $null, wenn Schluessel oder Wert fehlen, sonst ein Objekt mit Type und Value
    param([string]$Path, [string]$Name)
    $key = Open-TWRegKey -Path $Path
    if (-not $key) { return $null }
    try {
        if ($key.GetValueNames() -notcontains $Name) { return $null }
        [pscustomobject]@{
            Type  = $key.GetValueKind($Name).ToString()
            Value = $key.GetValue($Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        }
    } finally { $key.Close() }
}

function Get-TWRegValueNames {
    param([string]$Path)
    $key = Open-TWRegKey -Path $Path
    if (-not $key) { return @() }
    try { return @($key.GetValueNames() | Where-Object { $_ }) } finally { $key.Close() }
}

function Set-TWRegValue {
    param([string]$Path, [string]$Name, [string]$Type, $Value)
    $kind = [Microsoft.Win32.RegistryValueKind]$Type
    switch ($Type) {
        'DWord' { $Value = [int]$Value }
        'QWord' { $Value = [long]$Value }
        'Binary' { $Value = [byte[]]$Value }
        'MultiString' { $Value = [string[]]$Value }
        default { $Value = [string]$Value }
    }
    $key = Open-TWRegKey -Path $Path -Create
    try { $key.SetValue($Name, $Value, $kind) } finally { $key.Close() }
}

function Remove-TWRegValue {
    param([string]$Path, [string]$Name)
    $key = Open-TWRegKey -Path $Path -Writable
    if ($key) { try { $key.DeleteValue($Name, $false) } finally { $key.Close() } }
}

# --- Sicherung ------------------------------------------------------------------------------
# backup.json enthaelt pro Tweak-Id den Zustand VOR der ersten Aenderung.

function Get-TWBackup {
    $result = @{}
    if (-not (Test-Path -LiteralPath $script:BackupFile)) { return $result }
    $raw = Get-Content -LiteralPath $script:BackupFile -Raw -Encoding UTF8
    if ([string]::IsNullOrWhiteSpace($raw)) { return $result }
    $obj = $raw | ConvertFrom-Json
    foreach ($p in $obj.PSObject.Properties) { $result[$p.Name] = $p.Value }
    return $result
}

function Save-TWBackup {
    param([hashtable]$Backup)
    $dir = Split-Path -Parent $script:BackupFile
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    if ($PSVersionTable.PSVersion.Major -lt 6) {
        # Windows PowerShell 5.1 schreibt Arrays sonst als {"value":[...],"Count":n}
        Remove-TypeData -TypeName System.Array -ErrorAction SilentlyContinue
    }
    ConvertTo-Json -InputObject $Backup -Depth 8 | Set-Content -LiteralPath $script:BackupFile -Encoding UTF8
}

function Get-TWRegistryState {
    param($Tweak)
    , @(foreach ($r in $Tweak.Registry) {
            $cur = Get-TWRegValue -Path $r.Path -Name $r.Name
            [pscustomobject]@{
                Path    = $r.Path
                Name    = $r.Name
                Existed = [bool]$cur
                Type    = $(if ($cur) { $cur.Type } else { $r.Type })
                Value   = $(if ($cur) { $cur.Value } else { $null })
            }
        })
}

function Restore-TWRegistryState {
    param($State)
    foreach ($s in @($State)) {
        if (-not $s -or -not $s.Path) { continue }
        if ($s.Existed) { Set-TWRegValue -Path $s.Path -Name $s.Name -Type $s.Type -Value $s.Value }
        else { Remove-TWRegValue -Path $s.Path -Name $s.Name }
    }
}

# --- Tweak-Engine ---------------------------------------------------------------------------
# Ein Tweak ist eine Hashtable. Entweder mit Registry = @(@{ Path; Name; Type; On; Off }) -
# Off = $null heisst "Wert loeschen", Missing = Standard, wenn der Wert fehlt -
# oder mit eigenen Skriptbloecken Capture/Apply/Revert/Test.

function Test-TWValueEqual {
    param($Current, $Expected)
    if ($Current -is [array] -or $Expected -is [array]) { return ((@($Current) -join ',') -eq (@($Expected) -join ',')) }
    return ("$Current" -eq "$Expected")
}

function Test-TWTweak {
    param($Tweak)
    if ($Tweak.Test) { return [bool](& $Tweak.Test) }
    foreach ($r in $Tweak.Registry) {
        $cur = Get-TWRegValue -Path $r.Path -Name $r.Name
        if (-not $cur) {
            # Missing = Wert, von dem Windows ausgeht, wenn nichts eingetragen ist
            if ($r.ContainsKey('Missing') -and (Test-TWValueEqual $r.Missing $r.On)) { continue }
            return $false
        }
        if (-not (Test-TWValueEqual $cur.Value $r.On)) { return $false }
    }
    return $true
}

function Invoke-TWTweak {
    param($Tweak, [ValidateSet('Apply', 'Revert')][string]$Action)
    $backup = Get-TWBackup
    if ($Action -eq 'Apply') {
        if (-not $backup.ContainsKey($Tweak.Id)) {
            # Nur beim ersten Mal sichern, sonst wuerde der Original-Zustand ueberschrieben
            if ($Tweak.Capture) { $backup[$Tweak.Id] = & $Tweak.Capture }
            else { $backup[$Tweak.Id] = Get-TWRegistryState -Tweak $Tweak }
            Save-TWBackup -Backup $backup
        }
        if ($Tweak.Apply) { & $Tweak.Apply }
        else {
            foreach ($r in $Tweak.Registry) { Set-TWRegValue -Path $r.Path -Name $r.Name -Type $r.Type -Value $r.On }
        }
    } else {
        $saved = $null
        $hasBackup = $backup.ContainsKey($Tweak.Id)
        if ($hasBackup) { $saved = $backup[$Tweak.Id] }
        if ($Tweak.Revert) { & $Tweak.Revert $saved }
        elseif ($hasBackup) { Restore-TWRegistryState -State $saved }
        else {
            # Kein Backup (war schon vorher so eingestellt): auf den "Aus"-Zustand setzen
            foreach ($r in $Tweak.Registry) {
                if ($null -eq $r.Off) { Remove-TWRegValue -Path $r.Path -Name $r.Name }
                else { Set-TWRegValue -Path $r.Path -Name $r.Name -Type $r.Type -Value $r.Off }
            }
        }
        if ($hasBackup) {
            $backup.Remove($Tweak.Id)
            Save-TWBackup -Backup $backup
        }
    }
    if ($Tweak.After) { & $Tweak.After }
}

function Undo-TWAll {
    # Setzt alles zurueck, was in backup.json steht. Liefert die Zahl der Fehler.
    $errors = 0
    $backup = Get-TWBackup
    foreach ($id in @($backup.Keys)) {
        $tweak = $script:Tweaks | Where-Object { $_.Id -eq $id } | Select-Object -First 1
        try {
            if ($tweak) {
                Invoke-TWTweak -Tweak $tweak -Action Revert
                Write-TWLog "$($tweak.Name): zurückgesetzt" Ok
            } else {
                # z. B. Pro-Tweak, aber jetzt laeuft die Gratis-Version: Registry-Sicherung trotzdem anwenden
                Restore-TWRegistryState -State $backup[$id]
                $current = Get-TWBackup
                $current.Remove($id)
                Save-TWBackup -Backup $current
                Write-TWLog "$id`: zurückgesetzt" Ok
            }
        } catch {
            $errors++
            Write-TWLog "$id konnte nicht zurückgesetzt werden: $($_.Exception.Message)" Error
        }
    }
    return $errors
}

# ------------------------------------------------------------------ Tweaks (Gratis-Version)
# Felder: Id, Name, Effect (ehrlich: was bringt es wirklich?), Category (Gaming/Netzwerk),
#         Recommended (fuer "Empfohlene Einstellungen"), Restart, Registry oder Capture/Apply/Revert/Test, After

$script:BalancedScheme = '381b4222-f694-41f0-9685-ff5bb260df2e'
$script:UltimateScheme = 'e9a42b02-d5df-448d-aa00-03f14749eb61'
$script:HighScheme     = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
$script:OwnSchemeName  = 'TweakWerk Gaming'
$script:GuidPattern    = '[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}'

function Get-TWActivePowerScheme {
    $out = (powercfg /getactivescheme) -join ' '
    if ($out -match $script:GuidPattern) { return $Matches[0].ToLower() }
    return $null
}

function Get-TWOwnPowerScheme {
    foreach ($line in (powercfg /list)) {
        if ($line -match "($($script:GuidPattern))\s+\((.+?)\)" -and $Matches[2] -eq $script:OwnSchemeName) {
            return $Matches[1].ToLower()
        }
    }
    return $null
}

function New-TWOwnPowerScheme {
    # "Ultimative Leistung" kopieren, sonst "Hoechstleistung". Manche Laptops (Modern Standby) koennen beides nicht.
    foreach ($template in @($script:UltimateScheme, $script:HighScheme)) {
        $out = (powercfg /duplicatescheme $template 2>&1) -join ' '
        if ($LASTEXITCODE -eq 0 -and $out -match $script:GuidPattern) {
            $guid = $Matches[0].ToLower()
            powercfg /changename $guid $script:OwnSchemeName 'Erstellt von TweakWerk' | Out-Null
            return $guid
        }
    }
    throw 'Dein PC bietet keinen Höchstleistungs-Energieplan an (typisch für Laptops mit Modern Standby). Nutze dort den Windows-Energiemodus "Beste Leistung".'
}

function Test-TWIsLaptop {
    return [bool](Get-CimInstance -ClassName Win32_Battery -ErrorAction SilentlyContinue)
}

function Update-TWMouseSettings {
    # Neue Mauswerte sofort anwenden, ohne Abmelden (SPI_SETMOUSE)
    if (-not ('TweakWerk.Native' -as [type])) {
        Add-Type -Namespace TweakWerk -Name Native -MemberDefinition @'
[DllImport("user32.dll", SetLastError = true)]
public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, int[] pvParam, uint fWinIni);
'@
    }
    $path = 'HKCU:\Control Panel\Mouse'
    $values = [int[]]@(
        [int](Get-TWRegValue -Path $path -Name 'MouseThreshold1').Value,
        [int](Get-TWRegValue -Path $path -Name 'MouseThreshold2').Value,
        [int](Get-TWRegValue -Path $path -Name 'MouseSpeed').Value
    )
    [void][TweakWerk.Native]::SystemParametersInfo(0x0004, 0, $values, 0x03)
}

$script:Tweaks = @(
    @{
        Id          = 'PowerPlan'
        Name        = 'Energieplan „Ultimative Leistung“'
        Effect      = 'Die CPU taktet nicht mehr ständig herunter. Das bringt stabilere FPS und weniger kurze Ruckler, vor allem in CPU-lastigen Spielen. Auf Laptops: mehr Akkuverbrauch und Wärme.'
        Category    = 'Gaming'
        Recommended = $true
        NotOnLaptop = $true   # bei "Empfohlene Einstellungen" auf Laptops auslassen (Akku)
        Capture     = { [pscustomobject]@{ PreviousGuid = Get-TWActivePowerScheme } }
        Apply       = {
            $guid = Get-TWOwnPowerScheme
            if (-not $guid) { $guid = New-TWOwnPowerScheme }
            powercfg /setactive $guid | Out-Null
            if ($LASTEXITCODE -ne 0) { throw 'Energieplan konnte nicht aktiviert werden.' }
        }
        Revert      = {
            param($Saved)
            $previous = $script:BalancedScheme
            if ($Saved -and $Saved.PreviousGuid) { $previous = $Saved.PreviousGuid }
            powercfg /setactive $previous | Out-Null
            if ($LASTEXITCODE -ne 0) { powercfg /setactive $script:BalancedScheme | Out-Null }
            $own = Get-TWOwnPowerScheme
            if ($own -and $own -ne (Get-TWActivePowerScheme)) { powercfg /delete $own | Out-Null }
        }
        Test        = {
            $own = Get-TWOwnPowerScheme
            [bool]($own -and $own -eq (Get-TWActivePowerScheme))
        }
    }
    @{
        Id          = 'GameMode'
        Name        = 'Windows-Spielmodus'
        Effect      = 'Windows gibt dem laufenden Spiel Vorrang und verschiebt Update-Installationen und Hintergrundaufgaben. Bei Windows 11 meist schon an. Dann zeigt der Schalter das einfach an.'
        Category    = 'Gaming'
        Recommended = $true
        Registry    = @(
            @{ Path = 'HKCU:\Software\Microsoft\GameBar'; Name = 'AutoGameModeEnabled'; Type = 'DWord'; On = 1; Off = 0; Missing = 1 }
            @{ Path = 'HKCU:\Software\Microsoft\GameBar'; Name = 'AllowAutoGameMode'; Type = 'DWord'; On = 1; Off = 0; Missing = 1 }
        )
    }
    @{
        Id          = 'GameDVR'
        Name        = 'Xbox-Aufnahme im Hintergrund aus'
        Effect      = 'Windows zeichnet nicht mehr nebenbei dein Gameplay auf. Das spart Leistung, vor allem auf schwächeren PCs. Danach funktioniert Win+Alt+R (Clip aufnehmen) nicht mehr. Für Clips nimm OBS, Nvidia oder AMD.'
        Category    = 'Gaming'
        Recommended = $true
        Registry    = @(
            @{ Path = 'HKCU:\System\GameConfigStore'; Name = 'GameDVR_Enabled'; Type = 'DWord'; On = 0; Off = 1 }
            @{ Path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR'; Name = 'AppCaptureEnabled'; Type = 'DWord'; On = 0; Off = 1 }
            @{ Path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR'; Name = 'HistoricalCaptureEnabled'; Type = 'DWord'; On = 0; Off = $null }
        )
    }
    @{
        Id          = 'MouseAccel'
        Name        = 'Mausbeschleunigung aus'
        Effect      = 'Gleiche Handbewegung = gleiche Strecke auf dem Bildschirm, egal wie schnell du die Maus bewegst. Hilft beim Zielen in Shootern. Fühlt sich die ersten Tage ungewohnt an.'
        Category    = 'Gaming'
        Recommended = $false
        Registry    = @(
            @{ Path = 'HKCU:\Control Panel\Mouse'; Name = 'MouseSpeed'; Type = 'String'; On = '0'; Off = '1' }
            @{ Path = 'HKCU:\Control Panel\Mouse'; Name = 'MouseThreshold1'; Type = 'String'; On = '0'; Off = '6' }
            @{ Path = 'HKCU:\Control Panel\Mouse'; Name = 'MouseThreshold2'; Type = 'String'; On = '0'; Off = '10' }
        )
        After       = { Update-TWMouseSettings }
    }
)

# Vorschau der Pro-Funktionen fuer die Gratis-Version (nur Texte, kein Code)
$script:ProTeasers = @(
    @{ Id = 'HAGS'; Category = 'Gaming'; Name = 'Hardware-beschleunigte GPU-Planung'; Effect = 'Kann Input-Lag senken und ist Pflicht für DLSS Frame Generation.' }
    @{ Id = 'DeliveryOpt'; Category = 'Netzwerk'; Name = 'Update-Upload an fremde PCs aus'; Effect = 'Windows verteilt keine Updates mehr über deine Leitung an andere PCs.' }
    @{ Id = 'DnsCloudflare'; Category = 'Netzwerk'; Name = 'Schneller DNS (Cloudflare 1.1.1.1)'; Effect = 'Launcher und Webseiten finden ihre Server schneller.' }
)

# ------------------------------------------------------------------ Werkzeuge: System-Info, Sicherung, Aufraeumen, Ping

$script:RestorePointCreated = $false

function Get-TWSystemInfo {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem
    $cpu = Get-CimInstance -ClassName Win32_Processor | Select-Object -First 1
    $gpus = @(Get-CimInstance -ClassName Win32_VideoController |
            Where-Object { $_.Name -notmatch 'Basic|Remote|Virtual|Parsec|Meta' } |
            ForEach-Object { $_.Name.Trim() })
    $drive = Get-PSDrive -Name $env:SystemDrive.TrimEnd(':')
    $isLaptop = Test-TWIsLaptop
    [pscustomobject]@{
        Windows = '{0} (Build {1})' -f $os.Caption.Replace('Microsoft ', ''), $os.BuildNumber
        CPU     = $cpu.Name.Trim()
        GPU     = $(if ($gpus) { $gpus -join ' + ' } else { 'unbekannt' })
        RAM     = '{0:N0} GB' -f ($os.TotalVisibleMemorySize / 1MB)
        Disk    = '{0:N0} GB frei von {1:N0} GB' -f ($drive.Free / 1GB), (($drive.Used + $drive.Free) / 1GB)
        Device  = $(if ($isLaptop) { 'Laptop' } else { 'Desktop-PC' })
        Laptop  = $isLaptop
    }
}

function New-TWRestorePoint {
    # Windows erlaubt normalerweise nur einen Wiederherstellungspunkt pro 24 Stunden.
    # Die Sperre wird kurz aufgehoben und danach wieder auf den alten Wert gesetzt.
    $key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore'
    $old = Get-TWRegValue -Path $key -Name 'SystemRestorePointCreationFrequency'
    try {
        Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction Stop
        Set-TWRegValue -Path $key -Name 'SystemRestorePointCreationFrequency' -Type 'DWord' -Value 0
        Checkpoint-Computer -Description "$script:AppName Sicherung" -RestorePointType 'MODIFY_SETTINGS' -ErrorAction Stop
        $script:RestorePointCreated = $true
        Write-TWLog 'Wiederherstellungspunkt erstellt.' Ok
        return $true
    } catch {
        Write-TWLog "Wiederherstellungspunkt fehlgeschlagen: $($_.Exception.Message)" Error
        return $false
    } finally {
        if ($old) { Set-TWRegValue -Path $key -Name 'SystemRestorePointCreationFrequency' -Type $old.Type -Value $old.Value }
        else { Remove-TWRegValue -Path $key -Name 'SystemRestorePointCreationFrequency' }
    }
}

# --- Aufraeumen -----------------------------------------------------------------------------

function Test-TWSafeTempDir {
    # Sicherheitsnetz: nur Ordner, die wirklich "Temp" heissen und kein Laufwerk sind.
    # Falls TEMP auf C:\ oder den Benutzerordner zeigt, wird NICHTS geloescht.
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    $trimmed = $Path.TrimEnd('\', '/')
    if ($trimmed -match '^[A-Za-z]:$') { return $false }
    return ((($trimmed -split '[\\/]')[-1]) -eq 'Temp')
}

function Get-TWTempTargets {
    $candidates = @($env:TEMP, (Join-Path $env:SystemRoot 'Temp'))
    @($candidates | Where-Object { (Test-TWSafeTempDir $_) -and (Test-Path -LiteralPath $_) } | Select-Object -Unique)
}

function Clear-TWTemp {
    param([int]$MinAgeHours = 24, [switch]$RecycleBin)
    $cutoff = (Get-Date).AddHours(-$MinAgeHours)
    $freed = 0L
    $deleted = 0
    $skipped = 0
    foreach ($dir in Get-TWTempTargets) {
        Write-TWLog "Räume auf: $dir"
        Update-TWUi
        $files = Get-ChildItem -LiteralPath $dir -Recurse -Force -File -ErrorAction SilentlyContinue |
            Where-Object { $_.LastWriteTime -lt $cutoff }
        foreach ($f in $files) {
            try {
                $size = $f.Length
                Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop
                $freed += $size
                $deleted++
            } catch { $skipped++ }   # Datei wird gerade benutzt - das ist normal
            if ((($deleted + $skipped) % 250) -eq 0) { Update-TWUi }
        }
        # Leere Unterordner entfernen (tiefste zuerst)
        Get-ChildItem -LiteralPath $dir -Recurse -Force -Directory -ErrorAction SilentlyContinue |
            Sort-Object { $_.FullName.Length } -Descending |
            ForEach-Object {
                if (-not (Get-ChildItem -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue)) {
                    Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
                }
            }
    }
    if ($RecycleBin) { Clear-RecycleBin -Force -ErrorAction SilentlyContinue }
    [pscustomobject]@{ FreedMB = [math]::Round($freed / 1MB, 1); Files = $deleted; Skipped = $skipped }
}

# --- Netzwerk -------------------------------------------------------------------------------
# Gemessen wird die TCP-Verbindungszeit zu Rechenzentren, in denen viele Spieleserver stehen.
# Das funktioniert auch dort, wo Ping (ICMP) blockiert ist, und entspricht etwa einem Ping.

$script:PingTargets = @(
    @{ Name = 'Frankfurt (EU Zentral)'; Host = 'ec2.eu-central-1.amazonaws.com' }
    @{ Name = 'Irland (EU West)'; Host = 'ec2.eu-west-1.amazonaws.com' }
    @{ Name = 'Stockholm (EU Nord)'; Host = 'ec2.eu-north-1.amazonaws.com' }
    @{ Name = 'Virginia (US Ost)'; Host = 'ec2.us-east-1.amazonaws.com' }
    @{ Name = 'Cloudflare (nächster Knoten)'; Host = '1.1.1.1' }
)

function Get-TWLatencyStats {
    param([double[]]$Samples, [int]$Lost)
    $total = $Samples.Count + $Lost
    if ($Samples.Count -eq 0) {
        return [pscustomobject]@{ Avg = $null; Min = $null; Max = $null; Jitter = $null; LossPct = 100; Rating = 'Keine Verbindung' }
    }
    $jitter = 0.0
    if ($Samples.Count -gt 1) {
        $diffs = for ($i = 1; $i -lt $Samples.Count; $i++) { [math]::Abs($Samples[$i] - $Samples[$i - 1]) }
        $jitter = ($diffs | Measure-Object -Average).Average
    }
    $avg = ($Samples | Measure-Object -Average).Average
    $rating = 'Hoch'
    if ($avg -lt 30) { $rating = 'Sehr gut' } elseif ($avg -lt 60) { $rating = 'Gut' } elseif ($avg -lt 100) { $rating = 'OK' }
    [pscustomobject]@{
        Avg     = [math]::Round($avg, 0)
        Min     = [math]::Round(($Samples | Measure-Object -Minimum).Minimum, 0)
        Max     = [math]::Round(($Samples | Measure-Object -Maximum).Maximum, 0)
        Jitter  = [math]::Round($jitter, 0)
        LossPct = [math]::Round(100 * $Lost / $total, 0)
        Rating  = $rating
    }
}

function Measure-TWLatency {
    param([string]$HostName, [int]$Port = 443, [int]$Count = 6, [int]$TimeoutMs = 1500)
    try {
        # Einmal vorher aufloesen, damit die DNS-Zeit nicht mitgemessen wird
        $ip = [System.Net.Dns]::GetHostAddresses($HostName) |
            Where-Object { $_.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork } |
            Select-Object -First 1
    } catch { $ip = $null }
    if (-not $ip) { return Get-TWLatencyStats -Samples @() -Lost $Count }

    $samples = New-Object System.Collections.Generic.List[double]
    $lost = 0
    for ($i = 0; $i -lt $Count; $i++) {
        $client = New-Object System.Net.Sockets.TcpClient
        try {
            $sw = [System.Diagnostics.Stopwatch]::StartNew()
            $task = $client.ConnectAsync($ip, $Port)
            if ($task.Wait($TimeoutMs) -and $client.Connected) { $samples.Add($sw.Elapsed.TotalMilliseconds) }
            else { $lost++ }
        } catch { $lost++ }
        finally { $client.Close() }
        Update-TWUi
    }
    return Get-TWLatencyStats -Samples $samples.ToArray() -Lost $lost
}

function Clear-TWDnsCache {
    Clear-DnsClientCache
    Write-TWLog 'DNS-Cache geleert.' Ok
}

# ------------------------------------------------------------------ Oberflaeche (XAML)
$script:Xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="TweakWerk" Width="1060" Height="740" MinWidth="900" MinHeight="600"
        WindowStartupLocation="CenterScreen" Background="#0D1117" Foreground="#E6EDF3"
        FontFamily="Segoe UI" FontSize="13" UseLayoutRounding="True">
  <Window.Resources>
    <Style x:Key="Card" TargetType="Border">
      <Setter Property="Background" Value="#161B22"/>
      <Setter Property="BorderBrush" Value="#30363D"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="CornerRadius" Value="12"/>
      <Setter Property="Padding" Value="18,14"/>
      <Setter Property="Margin" Value="0,0,0,10"/>
    </Style>

    <Style x:Key="Switch" TargetType="CheckBox">
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="CheckBox">
            <Grid Width="48" Height="26" Background="Transparent">
              <Border x:Name="Track" CornerRadius="13" Background="#30363D"/>
              <Ellipse x:Name="Knob" Width="20" Height="20" Fill="#E6EDF3" HorizontalAlignment="Left" Margin="3,0,0,0"/>
            </Grid>
            <ControlTemplate.Triggers>
              <Trigger Property="IsChecked" Value="True">
                <Setter TargetName="Track" Property="Background" Value="#22C55E"/>
                <Setter TargetName="Knob" Property="HorizontalAlignment" Value="Right"/>
                <Setter TargetName="Knob" Property="Margin" Value="0,0,3,0"/>
              </Trigger>
              <Trigger Property="IsEnabled" Value="False">
                <Setter Property="Opacity" Value="0.35"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="Btn" TargetType="Button">
      <Setter Property="Background" Value="#2DD4BF"/>
      <Setter Property="Foreground" Value="#0D1117"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Padding" Value="16,9"/>
      <Setter Property="Margin" Value="0,0,10,0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="Bd" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}"
                    BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="8" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter TargetName="Bd" Property="Opacity" Value="0.85"/>
              </Trigger>
              <Trigger Property="IsEnabled" Value="False">
                <Setter TargetName="Bd" Property="Opacity" Value="0.4"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style x:Key="BtnGhost" TargetType="Button" BasedOn="{StaticResource Btn}">
      <Setter Property="Background" Value="Transparent"/>
      <Setter Property="Foreground" Value="#E6EDF3"/>
      <Setter Property="BorderBrush" Value="#30363D"/>
      <Setter Property="BorderThickness" Value="1"/>
    </Style>
    <Style x:Key="BtnPro" TargetType="Button" BasedOn="{StaticResource Btn}">
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="Background">
        <Setter.Value>
          <LinearGradientBrush StartPoint="0,0" EndPoint="1,0">
            <GradientStop Color="#A855F7" Offset="0"/>
            <GradientStop Color="#EC4899" Offset="1"/>
          </LinearGradientBrush>
        </Setter.Value>
      </Setter>
    </Style>

    <Style TargetType="TabItem">
      <Setter Property="Foreground" Value="#8B949E"/>
      <Setter Property="FontSize" Value="14"/>
      <Setter Property="Width" Value="200"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="TabItem">
            <Border x:Name="Bd" Padding="14,10" Margin="0,2" CornerRadius="8" Background="Transparent">
              <ContentPresenter ContentSource="Header"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter TargetName="Bd" Property="Background" Value="#161B22"/>
              </Trigger>
              <Trigger Property="IsSelected" Value="True">
                <Setter TargetName="Bd" Property="Background" Value="#12302C"/>
                <Setter Property="Foreground" Value="#2DD4BF"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="Icon" TargetType="TextBlock">
      <Setter Property="FontFamily" Value="Segoe MDL2 Assets"/>
      <Setter Property="Width" Value="26"/>
      <Setter Property="VerticalAlignment" Value="Center"/>
    </Style>
    <Style x:Key="H1" TargetType="TextBlock">
      <Setter Property="FontSize" Value="24"/>
      <Setter Property="FontWeight" Value="Bold"/>
      <Setter Property="Margin" Value="0,0,0,4"/>
    </Style>
    <Style x:Key="Sub" TargetType="TextBlock">
      <Setter Property="Foreground" Value="#8B949E"/>
      <Setter Property="TextWrapping" Value="Wrap"/>
      <Setter Property="Margin" Value="0,0,0,16"/>
    </Style>
    <Style x:Key="H2" TargetType="TextBlock">
      <Setter Property="FontSize" Value="16"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Margin" Value="0,0,0,6"/>
    </Style>
    <Style x:Key="Muted" TargetType="TextBlock">
      <Setter Property="Foreground" Value="#8B949E"/>
      <Setter Property="TextWrapping" Value="Wrap"/>
    </Style>
    <Style x:Key="InfoLabel" TargetType="TextBlock">
      <Setter Property="Foreground" Value="#8B949E"/>
      <Setter Property="FontSize" Value="11"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
    </Style>
    <Style x:Key="InfoValue" TargetType="TextBlock">
      <Setter Property="FontSize" Value="14"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="TextWrapping" Value="Wrap"/>
      <Setter Property="Margin" Value="0,4,0,0"/>
    </Style>
    <Style TargetType="CheckBox">
      <Setter Property="Foreground" Value="#E6EDF3"/>
    </Style>
  </Window.Resources>

  <Grid>
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="*"/>
      <RowDefinition Height="130"/>
    </Grid.RowDefinitions>

    <!-- Kopfzeile -->
    <Border Grid.Row="0" Padding="20,14" BorderBrush="#21262D" BorderThickness="0,0,0,1">
      <DockPanel LastChildFill="False">
        <StackPanel DockPanel.Dock="Left" Orientation="Horizontal" VerticalAlignment="Center">
          <TextBlock Text="&#xE945;" FontFamily="Segoe MDL2 Assets" FontSize="22" Foreground="#2DD4BF" VerticalAlignment="Center" Margin="0,0,10,0"/>
          <TextBlock Text="TweakWerk" FontSize="20" FontWeight="Bold" VerticalAlignment="Center"/>
          <Border x:Name="EditionBadge" CornerRadius="6" Padding="8,2" Margin="12,0,0,0" Background="#30363D" VerticalAlignment="Center">
            <TextBlock x:Name="EditionText" Text="GRATIS" FontSize="11" FontWeight="Bold"/>
          </Border>
          <TextBlock x:Name="VersionText" Text="" Foreground="#6E7681" FontSize="11" VerticalAlignment="Center" Margin="10,0,0,0"/>
        </StackPanel>
        <Button x:Name="BtnPro" DockPanel.Dock="Right" Style="{StaticResource BtnPro}" Margin="0" Content="Pro freischalten"/>
      </DockPanel>
    </Border>

    <!-- Hauptbereich -->
    <TabControl x:Name="Tabs" Grid.Row="1" TabStripPlacement="Left" Background="Transparent" BorderThickness="0" Padding="0" Margin="12,12,0,0">

      <TabItem>
        <TabItem.Header>
          <StackPanel Orientation="Horizontal"><TextBlock Style="{StaticResource Icon}" Text="&#xE80F;"/><TextBlock Text="Übersicht"/></StackPanel>
        </TabItem.Header>
        <ScrollViewer VerticalScrollBarVisibility="Auto" Padding="20,4,24,12">
          <StackPanel>
            <TextBlock Style="{StaticResource H1}" Text="Mehr aus deinem PC holen. Ehrlich."/>
            <TextBlock Style="{StaticResource Sub}" Text="Jede Änderung wird vorher gesichert und lässt sich mit einem Klick rückgängig machen. Keine Wunder-Versprechen: Nur Einstellungen, die wirklich etwas bringen."/>

            <UniformGrid Columns="3" Margin="0,0,0,6">
              <Border Style="{StaticResource Card}" Margin="0,0,10,10"><StackPanel><TextBlock Style="{StaticResource InfoLabel}" Text="WINDOWS"/><TextBlock x:Name="InfoWindows" Style="{StaticResource InfoValue}" Text="…"/></StackPanel></Border>
              <Border Style="{StaticResource Card}" Margin="0,0,10,10"><StackPanel><TextBlock Style="{StaticResource InfoLabel}" Text="PROZESSOR"/><TextBlock x:Name="InfoCpu" Style="{StaticResource InfoValue}" Text="…"/></StackPanel></Border>
              <Border Style="{StaticResource Card}" Margin="0,0,0,10"><StackPanel><TextBlock Style="{StaticResource InfoLabel}" Text="GRAFIKKARTE"/><TextBlock x:Name="InfoGpu" Style="{StaticResource InfoValue}" Text="…"/></StackPanel></Border>
              <Border Style="{StaticResource Card}" Margin="0,0,10,10"><StackPanel><TextBlock Style="{StaticResource InfoLabel}" Text="ARBEITSSPEICHER"/><TextBlock x:Name="InfoRam" Style="{StaticResource InfoValue}" Text="…"/></StackPanel></Border>
              <Border Style="{StaticResource Card}" Margin="0,0,10,10"><StackPanel><TextBlock Style="{StaticResource InfoLabel}" Text="SYSTEMLAUFWERK"/><TextBlock x:Name="InfoDisk" Style="{StaticResource InfoValue}" Text="…"/></StackPanel></Border>
              <Border Style="{StaticResource Card}" Margin="0,0,0,10"><StackPanel><TextBlock Style="{StaticResource InfoLabel}" Text="GERÄT"/><TextBlock x:Name="InfoDevice" Style="{StaticResource InfoValue}" Text="…"/></StackPanel></Border>
            </UniformGrid>

            <Border Style="{StaticResource Card}">
              <StackPanel>
                <TextBlock Style="{StaticResource H2}" Text="Schnellstart"/>
                <TextBlock Style="{StaticResource Muted}" Margin="0,0,0,12" Text="1. Wiederherstellungspunkt erstellen (dein Rettungsanker).  2. Empfohlene Einstellungen anwenden.  3. Spiel starten und vergleichen."/>
                <WrapPanel>
                  <Button x:Name="BtnRestore" Style="{StaticResource BtnGhost}" Content="Wiederherstellungspunkt erstellen"/>
                  <Button x:Name="BtnRecommended" Style="{StaticResource Btn}" Content="Empfohlene Einstellungen anwenden"/>
                </WrapPanel>
                <TextBlock x:Name="RestoreStatus" Style="{StaticResource Muted}" Margin="0,10,0,0" Text=""/>
              </StackPanel>
            </Border>

            <Border Style="{StaticResource Card}">
              <StackPanel>
                <TextBlock Style="{StaticResource H2}" Text="Was TweakWerk NICHT macht"/>
                <TextBlock Style="{StaticResource Muted}" Text="✖  Virenschutz, Firewall oder Windows-Updates abschalten&#x0a;✖  Placebo-Tweaks einbauen, die nur gut klingen&#x0a;✖  „+200 FPS“ versprechen. Wie viel es bringt, hängt von deinem PC ab. Auf aufgeräumten PCs sind es oft nur ein paar Prozent, dafür stabilere Frametimes."/>
              </StackPanel>
            </Border>
          </StackPanel>
        </ScrollViewer>
      </TabItem>

      <TabItem>
        <TabItem.Header>
          <StackPanel Orientation="Horizontal"><TextBlock Style="{StaticResource Icon}" Text="&#xE7FC;"/><TextBlock Text="Gaming"/></StackPanel>
        </TabItem.Header>
        <ScrollViewer VerticalScrollBarVisibility="Auto" Padding="20,4,24,12">
          <StackPanel>
            <TextBlock Style="{StaticResource H1}" Text="Gaming"/>
            <TextBlock Style="{StaticResource Sub}" Text="Schalter an = Tweak aktiv. Schalter aus = zurück zum vorherigen Zustand."/>
            <StackPanel x:Name="GamingTweaks"/>

            <Border x:Name="GpuSection" Style="{StaticResource Card}" Margin="0,8,0,10">
              <StackPanel>
                <StackPanel Orientation="Horizontal">
                  <TextBlock Style="{StaticResource H2}" Text="Spiele auf der starken Grafikkarte"/>
                  <Border x:Name="GpuProBadge" CornerRadius="6" Padding="6,1" Margin="8,0,0,6" Background="#A855F7" VerticalAlignment="Center"><TextBlock Text="PRO" FontSize="10" FontWeight="Bold" Foreground="White"/></Border>
                </StackPanel>
                <TextBlock Style="{StaticResource Muted}" Margin="0,0,0,12" Text="Wichtig bei Laptops mit zwei Grafikchips: Windows startet Spiele manchmal auf dem schwachen Chip. Hier legst du fest, dass ein Spiel immer die starke Grafikkarte nutzt."/>
                <StackPanel x:Name="GpuList" Margin="0,0,0,10"/>
                <WrapPanel>
                  <Button x:Name="BtnGpuAdd" Style="{StaticResource BtnGhost}" Content="Spiel hinzufügen (.exe)"/>
                </WrapPanel>
              </StackPanel>
            </Border>
          </StackPanel>
        </ScrollViewer>
      </TabItem>

      <TabItem>
        <TabItem.Header>
          <StackPanel Orientation="Horizontal"><TextBlock Style="{StaticResource Icon}" Text="&#xE774;"/><TextBlock Text="Netzwerk"/></StackPanel>
        </TabItem.Header>
        <ScrollViewer VerticalScrollBarVisibility="Auto" Padding="20,4,24,12">
          <StackPanel>
            <TextBlock Style="{StaticResource H1}" Text="Netzwerk &amp; Ping"/>
            <TextBlock Style="{StaticResource Sub}" Text="Erst messen, dann optimieren."/>

            <Border Style="{StaticResource Card}">
              <StackPanel>
                <TextBlock Style="{StaticResource H2}" Text="Ping-Test"/>
                <TextBlock Style="{StaticResource Muted}" Margin="0,0,0,12" Text="Misst deine Verbindungszeit zu Rechenzentren, in denen viele Spieleserver stehen. Dein Ping im Spiel kann etwas abweichen. Für die genauesten Werte: per LAN-Kabel und ohne laufende Downloads testen."/>
                <WrapPanel Margin="0,0,0,8">
                  <Button x:Name="BtnPing" Style="{StaticResource Btn}" Content="Ping testen"/>
                  <Button x:Name="BtnFlushDns" Style="{StaticResource BtnGhost}" Content="DNS-Cache leeren"/>
                </WrapPanel>
                <StackPanel x:Name="PingResults"/>
              </StackPanel>
            </Border>

            <StackPanel x:Name="NetworkTweaks"/>
          </StackPanel>
        </ScrollViewer>
      </TabItem>

      <TabItem>
        <TabItem.Header>
          <StackPanel Orientation="Horizontal"><TextBlock Style="{StaticResource Icon}" Text="&#xE74D;"/><TextBlock Text="Aufräumen"/></StackPanel>
        </TabItem.Header>
        <ScrollViewer VerticalScrollBarVisibility="Auto" Padding="20,4,24,12">
          <StackPanel>
            <TextBlock Style="{StaticResource H1}" Text="Aufräumen"/>
            <TextBlock Style="{StaticResource Sub}" Text="Löscht nur temporäre Dateien, die älter als 24 Stunden sind. Dateien, die gerade benutzt werden, bleiben automatisch liegen."/>
            <Border Style="{StaticResource Card}">
              <StackPanel>
                <TextBlock Style="{StaticResource H2}" Text="Temporäre Dateien"/>
                <TextBlock Style="{StaticResource Muted}" Margin="0,0,0,12" Text="Spart Speicherplatz. Mehr FPS bringt das nicht, aber auf vollen Laufwerken wird Windows träge."/>
                <CheckBox x:Name="ChkRecycle" Content="Auch den Papierkorb leeren" Margin="0,0,0,12"/>
                <WrapPanel><Button x:Name="BtnClean" Style="{StaticResource Btn}" Content="Jetzt aufräumen"/></WrapPanel>
                <TextBlock x:Name="CleanResult" Style="{StaticResource Muted}" Margin="0,10,0,0" Text=""/>
              </StackPanel>
            </Border>
          </StackPanel>
        </ScrollViewer>
      </TabItem>

      <TabItem>
        <TabItem.Header>
          <StackPanel Orientation="Horizontal"><TextBlock Style="{StaticResource Icon}" Text="&#xE768;"/><TextBlock Text="Autostart"/></StackPanel>
        </TabItem.Header>
        <ScrollViewer VerticalScrollBarVisibility="Auto" Padding="20,4,24,12">
          <StackPanel>
            <TextBlock Style="{StaticResource H1}" Text="Autostart"/>
            <TextBlock Style="{StaticResource Sub}" Text="Programme, die mit Windows starten, kosten Arbeitsspeicher und verlangsamen den Start. Hier schaltest du sie aus. Gelöscht wird nichts, du kannst sie jederzeit wieder einschalten."/>
            <StackPanel x:Name="StartupPanel">
              <Border Style="{StaticResource Card}" Background="#1F1A0E" BorderBrush="#5C4813">
                <TextBlock Style="{StaticResource Muted}" Foreground="#E3B341" Text="Schalte nur aus, was du kennst. Finger weg von Treibern (Audio, Touchpad, Grafik) und deinem Virenschutz."/>
              </Border>
              <WrapPanel Margin="0,0,0,10"><Button x:Name="BtnStartupRefresh" Style="{StaticResource BtnGhost}" Content="Liste aktualisieren"/></WrapPanel>
              <StackPanel x:Name="StartupList"/>
            </StackPanel>
            <Border x:Name="StartupLocked" Style="{StaticResource Card}">
              <StackPanel>
                <StackPanel Orientation="Horizontal">
                  <TextBlock Style="{StaticResource H2}" Text="Autostart-Manager"/>
                  <Border CornerRadius="6" Padding="6,1" Margin="8,0,0,6" Background="#A855F7" VerticalAlignment="Center"><TextBlock Text="PRO" FontSize="10" FontWeight="Bold" Foreground="White"/></Border>
                </StackPanel>
                <TextBlock Style="{StaticResource Muted}" Margin="0,0,0,12" Text="Sieh auf einen Blick, was alles mit Windows startet, und schalte unnötige Programme mit einem Klick aus."/>
                <WrapPanel><Button x:Name="BtnProStartup" Style="{StaticResource BtnPro}" Content="Pro freischalten"/></WrapPanel>
              </StackPanel>
            </Border>
          </StackPanel>
        </ScrollViewer>
      </TabItem>

      <TabItem>
        <TabItem.Header>
          <StackPanel Orientation="Horizontal"><TextBlock Style="{StaticResource Icon}" Text="&#xE81C;"/><TextBlock Text="Sicherung"/></StackPanel>
        </TabItem.Header>
        <ScrollViewer VerticalScrollBarVisibility="Auto" Padding="20,4,24,12">
          <StackPanel>
            <TextBlock Style="{StaticResource H1}" Text="Sicherung"/>
            <TextBlock Style="{StaticResource Sub}" Text="Dein Sicherheitsnetz. Hier machst du alles rückgängig."/>
            <Border Style="{StaticResource Card}">
              <StackPanel>
                <TextBlock Style="{StaticResource H2}" Text="Alles zurücksetzen"/>
                <TextBlock Style="{StaticResource Muted}" Margin="0,0,0,12" Text="Stellt den Zustand vor TweakWerk wieder her, für alle Schalter. Autostart-Einträge und Grafikkarten-Zuordnungen änderst du direkt in ihrem Bereich."/>
                <TextBlock x:Name="BackupInfo" Margin="0,0,0,12" Text=""/>
                <WrapPanel>
                  <Button x:Name="BtnUndoAll" Style="{StaticResource Btn}" Content="Alle Änderungen rückgängig machen"/>
                  <Button x:Name="BtnRestore2" Style="{StaticResource BtnGhost}" Content="Wiederherstellungspunkt erstellen"/>
                  <Button x:Name="BtnOpenData" Style="{StaticResource BtnGhost}" Content="Sicherungsordner öffnen"/>
                </WrapPanel>
              </StackPanel>
            </Border>
            <Border Style="{StaticResource Card}">
              <StackPanel>
                <TextBlock Style="{StaticResource H2}" Text="Notfall"/>
                <TextBlock Style="{StaticResource Muted}" Text="Falls Windows nach einer Änderung komisch reagiert: Windows-Taste drücken, „Wiederherstellungspunkt“ eingeben, „Systemwiederherstellung“ öffnen und den Punkt „TweakWerk Sicherung“ auswählen."/>
              </StackPanel>
            </Border>
          </StackPanel>
        </ScrollViewer>
      </TabItem>
    </TabControl>

    <!-- Protokoll -->
    <Border Grid.Row="2" Background="#0A0D12" BorderBrush="#21262D" BorderThickness="0,1,0,0" Padding="16,8">
      <DockPanel>
        <TextBlock DockPanel.Dock="Top" Style="{StaticResource InfoLabel}" Text="PROTOKOLL" Margin="0,0,0,4"/>
        <TextBox x:Name="LogBox" IsReadOnly="True" Background="Transparent" Foreground="#8B949E" BorderThickness="0"
                 FontFamily="Consolas" FontSize="12" VerticalScrollBarVisibility="Auto" TextWrapping="Wrap"/>
      </DockPanel>
    </Border>
  </Grid>
</Window>
'@

# ------------------------------------------------------------------ Oberflaeche (WPF)
# Alles, was Event-Handler spaeter brauchen, liegt im Script-Scope ($script:...).

$script:TweakSwitches = @()
$script:SafetyAsked = $false
$script:SysInfo = $null

function Get-TWControl {
    param([string]$Name)
    $control = $script:Window.FindName($Name)
    if (-not $control) { throw "Oberflächen-Element '$Name' fehlt." }
    return $control
}

function ConvertTo-TWBrush {
    param([string]$Color)
    return (New-Object System.Windows.Media.BrushConverter).ConvertFromString($Color)
}

function New-TWTextBlock {
    param([string]$Text, [double]$Size = 13, [string]$Color = '#E6EDF3', [switch]$Bold, [switch]$Wrap)
    $tb = New-Object System.Windows.Controls.TextBlock
    $tb.Text = $Text
    $tb.FontSize = $Size
    $tb.Foreground = ConvertTo-TWBrush $Color
    if ($Bold) { $tb.FontWeight = [System.Windows.FontWeights]::SemiBold }
    if ($Wrap) { $tb.TextWrapping = [System.Windows.TextWrapping]::Wrap }
    return $tb
}

function New-TWBadge {
    param([string]$Text, [string]$Color, [string]$TextColor = '#0D1117')
    $badge = New-Object System.Windows.Controls.Border
    $badge.CornerRadius = New-Object System.Windows.CornerRadius 6
    $badge.Padding = New-Object System.Windows.Thickness 6, 1, 6, 1
    $badge.Margin = New-Object System.Windows.Thickness 8, 0, 0, 0
    $badge.VerticalAlignment = 'Center'
    $badge.Background = ConvertTo-TWBrush $Color
    $label = New-TWTextBlock -Text $Text -Size 10 -Color $TextColor
    $label.FontWeight = [System.Windows.FontWeights]::Bold
    $badge.Child = $label
    return $badge
}

function New-TWRow {
    # Karte mit Titel, Badges, Beschreibung links und einem Element (Schalter/Knopf) rechts
    param([string]$Title, [string]$Text, [object[]]$Badges = @(), $Right, [switch]$Dim)
    $card = New-Object System.Windows.Controls.Border
    $card.Style = $script:Window.FindResource('Card')
    $grid = New-Object System.Windows.Controls.Grid
    $c0 = New-Object System.Windows.Controls.ColumnDefinition
    $c0.Width = New-Object System.Windows.GridLength 1, 'Star'
    $c1 = New-Object System.Windows.Controls.ColumnDefinition
    $c1.Width = [System.Windows.GridLength]::Auto
    $grid.ColumnDefinitions.Add($c0)
    $grid.ColumnDefinitions.Add($c1)

    $left = New-Object System.Windows.Controls.StackPanel
    $head = New-Object System.Windows.Controls.StackPanel
    $head.Orientation = 'Horizontal'
    [void]$head.Children.Add((New-TWTextBlock -Text $Title -Size 15 -Bold))
    foreach ($b in $Badges) { [void]$head.Children.Add($b) }
    [void]$left.Children.Add($head)
    if ($Text) {
        $desc = New-TWTextBlock -Text $Text -Color '#8B949E' -Wrap
        $desc.Margin = New-Object System.Windows.Thickness 0, 6, 0, 0
        [void]$left.Children.Add($desc)
    }
    [System.Windows.Controls.Grid]::SetColumn($left, 0)
    [void]$grid.Children.Add($left)

    if ($Right) {
        $Right.VerticalAlignment = 'Center'
        $Right.Margin = New-Object System.Windows.Thickness 18, 0, 0, 0
        [System.Windows.Controls.Grid]::SetColumn($Right, 1)
        [void]$grid.Children.Add($Right)
    }
    if ($Dim) { $card.Opacity = 0.6 }
    $card.Child = $grid
    return $card
}

function New-TWSwitch {
    $cb = New-Object System.Windows.Controls.CheckBox
    $cb.Style = $script:Window.FindResource('Switch')
    return $cb
}

function New-TWButton {
    param([string]$Text, [string]$Style = 'BtnGhost')
    $btn = New-Object System.Windows.Controls.Button
    $btn.Content = $Text
    $btn.Style = $script:Window.FindResource($Style)
    $btn.Margin = New-Object System.Windows.Thickness 0
    return $btn
}

# --- Ablauf-Helfer ---------------------------------------------------------------------------

function Invoke-TWBusy {
    # Sperrt die Oberflaeche waehrend einer Aktion und zeigt den Warte-Cursor
    param([scriptblock]$Action)
    $tabs = Get-TWControl 'Tabs'
    $script:Window.Cursor = [System.Windows.Input.Cursors]::Wait
    $tabs.IsEnabled = $false
    Update-TWUi
    try { & $Action }
    finally {
        $tabs.IsEnabled = $true
        $script:Window.Cursor = $null
    }
}

function Show-TWMessage {
    param([string]$Text, [string]$Buttons = 'OK', [string]$Icon = 'Information')
    return [System.Windows.MessageBox]::Show($script:Window, $Text, $script:AppName, $Buttons, $Icon)
}

function Confirm-TWSafety {
    # Vor der ersten Aenderung einmal fragen, ob ein Wiederherstellungspunkt erstellt werden soll
    if ($script:RestorePointCreated -or $script:SafetyAsked) { return $true }
    $answer = Show-TWMessage -Text ("Bevor du etwas änderst: Soll ich einen Wiederherstellungspunkt erstellen?`n`n" +
        "Das ist dein Rettungsanker, falls irgendetwas schiefgeht. Dauert etwa eine Minute.") -Buttons 'YesNoCancel' -Icon 'Question'
    if ("$answer" -eq 'Cancel') { return $false }
    $script:SafetyAsked = $true
    if ("$answer" -eq 'Yes') {
        Write-TWLog 'Erstelle Wiederherstellungspunkt … (kann eine Minute dauern)'
        Invoke-TWBusy { [void](New-TWRestorePoint) }
        Update-TWStatus
    }
    return $true
}

function Update-TWStatus {
    $status = Get-TWControl 'RestoreStatus'
    if ($script:RestorePointCreated) { $status.Text = '✔ Wiederherstellungspunkt in dieser Sitzung erstellt.' }
    else { $status.Text = 'Noch kein Wiederherstellungspunkt in dieser Sitzung.' }
    $count = (Get-TWBackup).Count
    $info = Get-TWControl 'BackupInfo'
    if ($count -eq 0) { $info.Text = 'Aktuell sind keine TweakWerk-Änderungen aktiv.' }
    else { $info.Text = "Aktive Änderungen mit Sicherung: $count" }
}

function Sync-TWSwitches {
    foreach ($cb in $script:TweakSwitches) {
        try { $cb.IsChecked = Test-TWTweak $cb.Tag } catch { $cb.IsChecked = $false }
    }
    Update-TWStatus
}

function Open-TWProPage {
    if ($script:ProUrl -match '^https?://') { Start-Process $script:ProUrl }
    else { [void](Show-TWMessage 'Die Pro-Version ist bald verfügbar.') }
}

# --- Aktionen ---------------------------------------------------------------------------------

function Invoke-TWToggleFromUi {
    param($CheckBox)
    $tweak = $CheckBox.Tag
    $enable = [bool]$CheckBox.IsChecked
    if (-not (Confirm-TWSafety)) {
        $CheckBox.IsChecked = -not $enable
        return
    }
    $action = 'Revert'
    if ($enable) { $action = 'Apply' }
    Invoke-TWBusy {
        try {
            Invoke-TWTweak -Tweak $tweak -Action $action
            if ($enable) { Write-TWLog "$($tweak.Name): aktiviert" Ok } else { Write-TWLog "$($tweak.Name): zurückgesetzt" Ok }
            if ($tweak.Restart) { Write-TWLog 'Wird nach einem Neustart wirksam.' Warn }
        } catch {
            Write-TWLog "$($tweak.Name) fehlgeschlagen: $($_.Exception.Message)" Error
        }
    }
    try { $CheckBox.IsChecked = Test-TWTweak $tweak } catch { }
    Update-TWStatus
}

function Invoke-TWRecommended {
    if (-not (Confirm-TWSafety)) { return }
    $isLaptop = [bool]($script:SysInfo -and $script:SysInfo.Laptop)
    $script:RestartNeeded = $false   # im Script-Scope, weil der Block unten in einem eigenen Scope laeuft
    Invoke-TWBusy {
        foreach ($t in @($script:Tweaks | Where-Object { $_.Recommended })) {
            if ($t.NotOnLaptop -and $isLaptop) {
                Write-TWLog "$($t.Name): auf Laptops ausgelassen (Akku). Kannst du im Gaming-Bereich selbst einschalten."
                continue
            }
            try {
                if (Test-TWTweak $t) { Write-TWLog "$($t.Name): war schon aktiv" }
                else {
                    Invoke-TWTweak -Tweak $t -Action Apply
                    Write-TWLog "$($t.Name): aktiviert" Ok
                    if ($t.Restart) { $script:RestartNeeded = $true }
                }
            } catch { Write-TWLog "$($t.Name) fehlgeschlagen: $($_.Exception.Message)" Error }
        }
    }
    Sync-TWSwitches
    if ($script:RestartNeeded) { Write-TWLog 'Einige Änderungen werden erst nach einem Neustart wirksam.' Warn }
    Write-TWLog 'Fertig. Starte jetzt ein Spiel und vergleiche.' Ok
}

function Invoke-TWPingTest {
    $panel = Get-TWControl 'PingResults'
    $panel.Children.Clear()
    Invoke-TWBusy {
        foreach ($target in $script:PingTargets) {
            Write-TWLog "Messe $($target.Name) …"
            $r = Measure-TWLatency -HostName $target.Host
            [void]$panel.Children.Add((New-TWPingRow -Name $target.Name -Result $r))
            Update-TWUi
        }
    }
    Write-TWLog 'Ping-Test fertig.' Ok
}

function New-TWPingRow {
    param([string]$Name, $Result)
    $grid = New-Object System.Windows.Controls.Grid
    $grid.Margin = New-Object System.Windows.Thickness 0, 4, 0, 4
    foreach ($w in @(230, 90, 90, 110, 120)) {
        $col = New-Object System.Windows.Controls.ColumnDefinition
        $col.Width = New-Object System.Windows.GridLength $w
        $grid.ColumnDefinitions.Add($col)
    }
    $colors = @{ 'Sehr gut' = '#22C55E'; 'Gut' = '#2DD4BF'; 'OK' = '#E3B341'; 'Hoch' = '#F97316'; 'Keine Verbindung' = '#F85149' }
    $cells = @(
        (New-TWTextBlock -Text $Name -Bold),
        (New-TWTextBlock -Text $(if ($null -ne $Result.Avg) { "$($Result.Avg) ms" } else { '–' }) -Bold),
        (New-TWTextBlock -Text $(if ($null -ne $Result.Jitter) { "± $($Result.Jitter) ms" } else { '–' }) -Color '#8B949E'),
        (New-TWTextBlock -Text "$($Result.LossPct) % Verlust" -Color $(if ($Result.LossPct -gt 0) { '#F85149' } else { '#8B949E' })),
        (New-TWTextBlock -Text $Result.Rating -Bold -Color $colors[$Result.Rating])
    )
    for ($i = 0; $i -lt $cells.Count; $i++) {
        [System.Windows.Controls.Grid]::SetColumn($cells[$i], $i)
        [void]$grid.Children.Add($cells[$i])
    }
    return $grid
}

function Invoke-TWClean {
    $recycle = [bool](Get-TWControl 'ChkRecycle').IsChecked
    $script:CleanResultData = $null
    Invoke-TWBusy { $script:CleanResultData = Clear-TWTemp -RecycleBin:$recycle }
    $r = $script:CleanResultData
    $text = '{0:N1} MB freigegeben ({1} Dateien gelöscht).' -f $r.FreedMB, $r.Files
    if ($r.Skipped -gt 0) { $text += " $($r.Skipped) Dateien waren gerade in Benutzung und wurden übersprungen. Das ist normal." }
    (Get-TWControl 'CleanResult').Text = $text
    Write-TWLog $text Ok
}

function Invoke-TWUndoAll {
    $answer = Show-TWMessage -Text 'Alle Änderungen von TweakWerk rückgängig machen?' -Buttons 'YesNo' -Icon 'Question'
    if ("$answer" -ne 'Yes') { return }
    $script:UndoErrors = 0
    Invoke-TWBusy { $script:UndoErrors = Undo-TWAll }
    Sync-TWSwitches
    if ($script:UndoErrors -eq 0) { Write-TWLog 'Alles zurückgesetzt.' Ok }
    else { [void](Show-TWMessage "Fertig, aber $($script:UndoErrors) Punkt(e) konnten nicht zurückgesetzt werden. Details im Protokoll." 'OK' 'Warning') }
}

# --- Pro-Bereiche -----------------------------------------------------------------------------

function Show-TWGpuList {
    $list = Get-TWControl 'GpuList'
    $list.Children.Clear()
    $games = @(Get-TWGpuPreferences)
    if (-not $games) {
        [void]$list.Children.Add((New-TWTextBlock -Text 'Noch keine Spiele hinzugefügt.' -Color '#6E7681'))
        return
    }
    foreach ($path in $games) {
        $btn = New-TWButton -Text 'Entfernen'
        $btn.Tag = $path
        $btn.Add_Click({
                try { Remove-TWGpuPreference -ExePath $this.Tag } catch { Write-TWLog "Entfernen fehlgeschlagen: $($_.Exception.Message)" Error }
                Show-TWGpuList
            })
        $row = New-TWRow -Title (Split-Path -Leaf $path) -Text $path -Right $btn
        $row.Background = ConvertTo-TWBrush '#0D1117'
        [void]$list.Children.Add($row)
    }
}

function Add-TWGpuGameFromDialog {
    $dialog = New-Object Microsoft.Win32.OpenFileDialog
    $dialog.Title = 'Spiel auswählen (die .exe-Datei)'
    $dialog.Filter = 'Programme (*.exe)|*.exe'
    if ($dialog.ShowDialog($script:Window)) {
        try { Add-TWGpuPreference -ExePath $dialog.FileName } catch { Write-TWLog "Hinzufügen fehlgeschlagen: $($_.Exception.Message)" Error }
        Show-TWGpuList
    }
}

function Show-TWStartupList {
    $list = Get-TWControl 'StartupList'
    $list.Children.Clear()
    $items = @()
    try { $items = @(Get-TWStartupItems) } catch { Write-TWLog "Autostart-Liste konnte nicht gelesen werden: $($_.Exception.Message)" Error }
    if (-not $items) {
        [void]$list.Children.Add((New-TWTextBlock -Text 'Keine Autostart-Einträge gefunden.' -Color '#6E7681'))
        return
    }
    foreach ($item in $items) {
        $toggle = New-TWSwitch
        $toggle.IsChecked = $item.Enabled
        $toggle.Tag = $item
        $toggle.Add_Click({
                $entry = $this.Tag
                $want = [bool]$this.IsChecked
                try {
                    Set-TWStartupItem -Item $entry -Enabled $want
                    $entry.Enabled = $want
                } catch {
                    Write-TWLog "Autostart '$($entry.Name)' fehlgeschlagen: $($_.Exception.Message)" Error
                    $this.IsChecked = -not $want
                }
            })
        $command = $item.Command
        if ($command.Length -gt 110) { $command = $command.Substring(0, 107) + '…' }
        $row = New-TWRow -Title $item.Name -Text $command -Badges @(New-TWBadge -Text $item.Source -Color '#30363D' -TextColor '#C9D1D9') -Right $toggle
        $row.ToolTip = $item.Command
        [void]$list.Children.Add($row)
    }
    $off = @($items | Where-Object { -not $_.Enabled }).Count
    Write-TWLog "Autostart: $($items.Count) Einträge, davon $off ausgeschaltet."
}

# --- Fenster ----------------------------------------------------------------------------------

function Add-TWTweakRows {
    param([string]$Category, [string]$PanelName)
    $panel = Get-TWControl $PanelName
    foreach ($tweak in @($script:Tweaks | Where-Object { $_.Category -eq $Category })) {
        $badges = @()
        if ($tweak.Recommended) { $badges += New-TWBadge -Text 'EMPFOHLEN' -Color '#2DD4BF' }
        if ($tweak.Pro) { $badges += New-TWBadge -Text 'PRO' -Color '#A855F7' -TextColor 'White' }
        if ($tweak.Restart) { $badges += New-TWBadge -Text 'NEUSTART' -Color '#E3B341' }
        $toggle = New-TWSwitch
        $toggle.Tag = $tweak
        $toggle.Add_Click({ Invoke-TWToggleFromUi -CheckBox $this })
        $script:TweakSwitches += $toggle
        [void]$panel.Children.Add((New-TWRow -Title $tweak.Name -Text $tweak.Effect -Badges $badges -Right $toggle))
    }
    # Gratis-Version: Pro-Funktionen als gesperrte Vorschau zeigen
    $existing = @($script:Tweaks | ForEach-Object { $_.Id })
    foreach ($teaser in @($script:ProTeasers | Where-Object { $_.Category -eq $Category -and $existing -notcontains $_.Id })) {
        $btn = New-TWButton -Text 'Pro freischalten' -Style 'BtnPro'
        $btn.Add_Click({ Open-TWProPage })
        $badges = @(New-TWBadge -Text 'PRO' -Color '#A855F7' -TextColor 'White')
        [void]$panel.Children.Add((New-TWRow -Title $teaser.Name -Text $teaser.Effect -Badges $badges -Right $btn -Dim))
    }
}

function Show-TWWindow {
    Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
    [xml]$xml = $script:Xaml
    $script:Window = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xml))
    $isPro = $script:Edition -eq 'Pro'

    # Protokoll
    $script:LogBox = Get-TWControl 'LogBox'
    $script:LogSink = {
        param($Line, $Level)
        $prefix = switch ($Level) { 'Ok' { '✔ ' } 'Warn' { '! ' } 'Error' { '✖ ' } default { '  ' } }
        $script:LogBox.AppendText("$prefix$Line`r`n")
        $script:LogBox.ScrollToEnd()
    }

    # Kopfzeile
    (Get-TWControl 'VersionText').Text = "v$script:AppVersion"
    if ($isPro) {
        (Get-TWControl 'EditionText').Text = 'PRO'
        (Get-TWControl 'EditionText').Foreground = ConvertTo-TWBrush 'White'
        (Get-TWControl 'EditionBadge').Background = ConvertTo-TWBrush '#A855F7'
        (Get-TWControl 'BtnPro').Visibility = 'Collapsed'
    }

    # Tweaks
    Add-TWTweakRows -Category 'Gaming' -PanelName 'GamingTweaks'
    Add-TWTweakRows -Category 'Netzwerk' -PanelName 'NetworkTweaks'

    # Pro-Bereiche ein- oder ausblenden
    if ($isPro) {
        (Get-TWControl 'StartupLocked').Visibility = 'Collapsed'
        (Get-TWControl 'GpuProBadge').Visibility = 'Collapsed'
        (Get-TWControl 'BtnGpuAdd').Add_Click({ Add-TWGpuGameFromDialog })
        (Get-TWControl 'BtnStartupRefresh').Add_Click({ Show-TWStartupList })
    } else {
        (Get-TWControl 'StartupPanel').Visibility = 'Collapsed'
        $gpuButton = Get-TWControl 'BtnGpuAdd'
        $gpuButton.Content = 'Pro freischalten'
        $gpuButton.Style = $script:Window.FindResource('BtnPro')
        $gpuButton.Add_Click({ Open-TWProPage })
        (Get-TWControl 'BtnProStartup').Add_Click({ Open-TWProPage })
    }

    # Knoepfe
    (Get-TWControl 'BtnPro').Add_Click({ Open-TWProPage })
    $restoreAction = {
        Write-TWLog 'Erstelle Wiederherstellungspunkt … (kann eine Minute dauern)'
        Invoke-TWBusy { [void](New-TWRestorePoint) }
        Update-TWStatus
    }
    (Get-TWControl 'BtnRestore').Add_Click($restoreAction)
    (Get-TWControl 'BtnRestore2').Add_Click($restoreAction)
    (Get-TWControl 'BtnRecommended').Add_Click({ Invoke-TWRecommended })
    (Get-TWControl 'BtnPing').Add_Click({ Invoke-TWPingTest })
    (Get-TWControl 'BtnFlushDns').Add_Click({ try { Clear-TWDnsCache } catch { Write-TWLog "DNS-Cache: $($_.Exception.Message)" Error } })
    (Get-TWControl 'BtnClean').Add_Click({ Invoke-TWClean })
    (Get-TWControl 'BtnUndoAll').Add_Click({ Invoke-TWUndoAll })
    (Get-TWControl 'BtnOpenData').Add_Click({ Start-Process explorer.exe $script:DataDir })

    # Beim Oeffnen: System-Info laden und Schalter auf den echten Zustand setzen
    $script:Window.Add_ContentRendered({
            Write-TWLog "$script:AppName $script:AppVersion ($script:Edition) gestartet."
            try {
                $script:SysInfo = Get-TWSystemInfo
                (Get-TWControl 'InfoWindows').Text = $script:SysInfo.Windows
                (Get-TWControl 'InfoCpu').Text = $script:SysInfo.CPU
                (Get-TWControl 'InfoGpu').Text = $script:SysInfo.GPU
                (Get-TWControl 'InfoRam').Text = $script:SysInfo.RAM
                (Get-TWControl 'InfoDisk').Text = $script:SysInfo.Disk
                (Get-TWControl 'InfoDevice').Text = $script:SysInfo.Device
            } catch { Write-TWLog "System-Info: $($_.Exception.Message)" Warn }
            Sync-TWSwitches
            if ($script:Edition -eq 'Pro') { Show-TWGpuList; Show-TWStartupList }
            Write-TWLog 'Bereit. Tipp: Erst einen Wiederherstellungspunkt erstellen.'
        })

    [void]$script:Window.ShowDialog()
}

# ------------------------------------------------------------------ Start

function Start-TWApp {
    $windowsPowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $relaunchArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-STA', '-File', ('"{0}"' -f $PSCommandPath))

    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
    $needsClassic = ($PSVersionTable.PSVersion.Major -gt 5) -or
        ([Threading.Thread]::CurrentThread.ApartmentState -ne [Threading.ApartmentState]::STA)

    # Adminrechte (fuer HKLM, Wiederherstellungspunkt, DNS) und Windows PowerShell 5.1 im STA-Modus (fuer WPF)
    if (-not $isAdmin -or $needsClassic) {
        try {
            if ($isAdmin) { Start-Process -FilePath $windowsPowerShell -ArgumentList $relaunchArgs }
            else { Start-Process -FilePath $windowsPowerShell -ArgumentList $relaunchArgs -Verb RunAs }
        } catch {
            Write-Host 'TweakWerk braucht Administratorrechte, um Einstellungen zu ändern. Bitte bei der Windows-Abfrage auf "Ja" klicken.'
            Start-Sleep -Seconds 5
        }
        return
    }

    if (-not (Test-Path -LiteralPath $script:DataDir)) { New-Item -ItemType Directory -Path $script:DataDir -Force | Out-Null }
    try {
        Show-TWWindow
    } catch {
        $message = "Unerwarteter Fehler: $($_.Exception.Message)`n`nDetails stehen in: $script:LogFile"
        try { Add-Content -LiteralPath $script:LogFile -Value "[Fatal] $($_ | Out-String)" -Encoding UTF8 } catch { }
        Add-Type -AssemblyName PresentationFramework
        [void][System.Windows.MessageBox]::Show($message, $script:AppName, 'OK', 'Error')
    }
}

Start-TWApp
