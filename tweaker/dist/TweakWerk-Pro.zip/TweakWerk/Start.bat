@echo off
rem Startet TweakWerk. Windows fragt einmal nach Administratorrechten.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0TweakWerk.ps1"
